<h2>Modifier une news</h2>
<form action="" method="post">
  <p>
    <?= $form ?>
    
    <input type="submit" value="Modifier" />
  </p>
</form>