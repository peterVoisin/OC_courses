OpenClassrooms: Programmez en orienté objet en PHP
==================================================
[Théorie] Les bases de la POO
-----------------------------
Activité : Créez un système de mise en cache

http://exercices.openclassrooms.com/assessment/instructions/144851
