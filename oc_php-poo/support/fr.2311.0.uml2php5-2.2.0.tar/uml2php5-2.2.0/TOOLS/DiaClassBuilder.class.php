<?php
/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Library General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * 
 *  Copyright 2005 KDO kdo@zpmag.com 
 */
 
 /**
  * Buid DIA XML fragments
  *
  * @version 0.1
  * @package   UMLTOOLS
  */

class DiaClassBuilder {
	
	private $PC ;
	private $XML = '';
	private $Level = 0;
	private $offset = NULL;
	private static $CC = 0;
	
	public function __construct($T) {
		$this->PC = $T;
	}

	public function getXML() {
		return $this->XML;
	}
	
	public final function buildDiaFile() {
		$this->XML .= '<?xml version="1.0"?>'."\n";
		$this->XML .= '<dia:diagram xmlns:dia="http://www.lysator.liu.se/~alla/dia/">'."\n";
		$this->XML .= '<dia:layer name="arrière-plan" visible="true">'."\n";
		$this->XML .= '</dia:layer>'."\n";
		$this->XML .= '</dia:diagram>';
	}


	public function buildClass($id, $level=0) {
		++self::$CC;
		$this->Level = $level;
		$this->XML .= '<?xml version="1.0"?>'."\n";
		$this->XML .= '<dia:diagram xmlns:dia="http://www.lysator.liu.se/~alla/dia/">'."\n";
//		$this->XML .= '<dia:object type="UML - Class" version="0">'."\n";
		$cname = $this->PC['classinfos']['name'];
		//echo "Building $cname \n";
		$T = & $this->PC['classinfos'];
		$this->XML .= $this->diaClassHeader($T, $id);
		$T = & $this->PC['properties'];
		$this->XML .= $this->diaClassProperties($T);
		$T = & $this->PC['methods'];
		$this->XML .= $this->diaClassOperations($T);
		$this->XML .= $this->diaClassFooter();
	}
	
	public function buildProperty() {
		$this->XML .= '<?xml version="1.0"?>'."\n";
		$this->XML .= '<dia:diagram xmlns:dia="http://www.lysator.liu.se/~alla/dia/">'."\n";
		$T = & $this->PC;
		$this->XML .= $this->diaClassProperty($T);
		$this->XML .= '</dia:diagram>';
	}

	public function buildMethod() {
		$this->XML .= '<?xml version="1.0"?>'."\n";
		$this->XML .= '<dia:diagram xmlns:dia="http://www.lysator.liu.se/~alla/dia/">'."\n";
		$T = & $this->PC;
		$this->XML .= $this->diaClassOperation($T);
		$this->XML .= '</dia:diagram>';
	}

	final private function diaClassHeader($T, $id) {
		$r  = '<dia:object type="UML - Class" version="0" id="O'.$id.'">'."\n";
		$r .= $this->diaClassPosition($T);
		$r .= ' <dia:attribute name="line_color"><dia:color val="#0000ff"/></dia:attribute>'."\n";
		$r .= ' <dia:attribute name="name"><dia:string>#'.$T['name'].'#</dia:string></dia:attribute>'."\n";
		$r .= ' <dia:attribute name="stereotype"><dia:string>'.$T['stereotype'].'</dia:string></dia:attribute>'."\n";
		$r .= ' <dia:attribute name="abstract"><dia:boolean val="'.$T['abstract'].'"/></dia:attribute>'."\n";
		$r .= ' <dia:attribute name="suppress_attributes"><dia:boolean val="false"/></dia:attribute>'."\n";
		$r .= ' <dia:attribute name="suppress_operations"><dia:boolean val="false"/></dia:attribute>'."\n";
		$r .= ' <dia:attribute name="visible_attributes"><dia:boolean val="true"/></dia:attribute>'."\n";
		$r .= ' <dia:attribute name="visible_operations"><dia:boolean val="true"/></dia:attribute>'."\n";
		return $r;
	}
	
	public function diaClassPosition($T) {
		$X = $this->calXpos($T) ;
		$Y = $this->calYpos($T) ;
		$r  = ' <dia:attribute name="obj_pos"><dia:point val="'.$X.','.$Y.'"/></dia:attribute>'."\n";
		$r .= ' <dia:attribute name="elem_corner"><dia:point val="'.$X.','.$Y.'"/></dia:attribute>'."\n";
		return $r;
	}
		
	public function diaClassFooter() {
		$r  = '<dia:attribute name="template"><dia:boolean val="false"/></dia:attribute>'."\n";
		$r .= '<dia:attribute name="templates"/>'."\n";
		$r .= '</dia:object></dia:diagram>';
		return $r;
	}


	public function diaClassProperties($T) {
		if (count($T) < 1) {
			return '<dia:attribute name="attributes"/>'."\n";
		}
		$r  = '<dia:attribute name="attributes">'."\n";
		foreach ($T as $P) {
			$r .= $this->diaClassProperty($P) ;
		}
		$r .= '</dia:attribute>'."\n";
		return $r;
	}

	public function diaClassProperty($T) {
		$r  = '<dia:composite type="umlattribute">'."\n";
		$r .= '<dia:attribute name="name"><dia:string>#'.$T['name'].'#</dia:string></dia:attribute>'."\n";
		$r .= '<dia:attribute name="type"><dia:string>#'.$T['type'].'#</dia:string></dia:attribute>'."\n";
		$r .= '<dia:attribute name="value"><dia:string>#'.$T['value'].'#</dia:string></dia:attribute>'."\n";
		$r .= '<dia:attribute name="visibility"><dia:enum val="'.$T['visibility'].'"/></dia:attribute>'."\n";
		$r .= '</dia:composite>'."\n";
		return $r;
	}
	
	public function diaClassOperations($T) {
		if (count($T) < 1) {
			return '<dia:attribute name="operations"/>'."\n";
		}
		$r  = '<dia:attribute name="operations">'."\n";
		foreach ($T as $P) {
			$r .= $this->diaClassOperation($P) ;
		}
		$r .= '</dia:attribute>'."\n";
		return $r;
	}

	public function diaClassOperation($T) {
		$r  = '<dia:composite type="umloperation">'."\n";
		$r .= '<dia:attribute name="name"><dia:string>#'.$T['name'].'#</dia:string></dia:attribute>'."\n";
		if (isset($T['type'])) {
			$r .= '<dia:attribute name="type"><dia:string>#'.$T['type'].'#</dia:string></dia:attribute>'."\n";
		}
		$r .= '<dia:attribute name="visibility"><dia:enum val="'.$T['visibility'].'"/></dia:attribute>'."\n";
		$r .= '<dia:attribute name="abstract"><dia:boolean val="'.$T['abstract'].'"/></dia:attribute>'."\n";
		$r .= '<dia:attribute name="class_scope"><dia:boolean val="'.$T['static'].'"/></dia:attribute>'."\n";

		$P = & $T['parameters'];
		$r .= $this->diaClassParameters($P);
		$r .= '</dia:composite>'."\n";
		return $r;
	}
	
	public function diaClassParameters($T) {
		if (count($T) < 1) {
			return '<dia:attribute name="parameters"/>'."\n";
		}
		$r  = '<dia:attribute name="parameters">'."\n";
		$SEP = '';
		foreach ($T as $P) {
			$r .= $this->diaClassParameter($P) ;
		}
		$r .= '</dia:attribute>'."\n";
		return $r;
	}
	
	public function diaClassParameter($T) {
		$r  = '<dia:composite type="umlparameter">'."\n";
		$r .= '<dia:attribute name="name"><dia:string>#'.$T['name'].'#</dia:string></dia:attribute>'."\n";
		$r .= '<dia:attribute name="type"><dia:string>#'.$T['type'].'#</dia:string></dia:attribute>'."\n";
		$r .= '<dia:attribute name="value"><dia:string>#'.$T['value'].'#</dia:string></dia:attribute>'."\n";
		
		$r .= '</dia:composite>'."\n";
		return $r;
	}
	
	public function diaGeneralization($T, $id) {
		//var_dump($T);die();
		$P  = $T['P'];
		$F  = $T['F'];
		$PX = $T['PX'];
		$PY = $T['PY'];
		$FX = $T['FX'];
		$FY = $T['FY'];
		$r  = '<?xml version="1.0"?>'."\n";
		$r .= '<dia:diagram xmlns:dia="http://www.lysator.liu.se/~alla/dia/">'."\n";
		$r .= '<dia:object type="UML - Generalization" version="0" id="O'.$id.'">'."\n";
		$r .= '<dia:attribute name="orth_points">'."\n";
		$r .= ' <dia:point val="'.$PX.','.$PY.'"/>'."\n";
		$r .= ' <dia:point val="'.$PX.','.($PY+1).'"/>'."\n";
		$r .= ' <dia:point val="'.$FX.','.($PY+1).'"/>'."\n";
		$r .= ' <dia:point val="'.$FX.','.$FY.'"/>'."\n";
		$r .= '</dia:attribute>'."\n";
		$r .= '<dia:attribute name="orth_orient">'."\n";
		$r .= ' <dia:enum val="1"/>'."\n";
		$r .= ' <dia:enum val="0"/>'."\n";
		$r .= ' <dia:enum val="1"/>'."\n";
		$r .= '</dia:attribute>'."\n";
		$r .= '<dia:connections>'."\n";
		$r .= '<dia:connection handle="0" to="'.$P.'" connection="6"/>'."\n";
		$r .= '<dia:connection handle="1" to="'.$F.'" connection="1"/>'."\n";
		$r .= '</dia:connections>'."\n";
		$r .= '</dia:object>'."\n";
		$r .= '</dia:diagram>'."\n";
		$this->XML = $r;
	}

	private final function calXpos($T) {
		static $lastlevel = 0 ;
		static $nextposX  = 0 ;
		
		if ($lastlevel != $this->Level) {
			$lastlevel = $this->Level;
			$nextposX  = 0 ;
		}
		$X = $nextposX ;
		$this->offset['X'] = $nextposX;
		$W = $T['W'] * 0.5 ;
		$nextposX += $W;
		return $X;
	}
	
	private final function calYpos($T) {
		static $lastlevel = 0 ;
		static $nextposY  = 0 ;
		static $maxH = 0;
		
		if ($lastlevel != $this->Level) {
			$lastlevel = $this->Level;
			$nextposY += $maxH ;
			$maxH = 0 ;
		}
		$Y = $nextposY ;
		$this->offset['Y'] = $nextposY;
		$H = $T['H']* 1.5 ;
		if($maxH < $H) {
			$maxH = $H ;
		}
		return $Y;
	}
	
	public final function getClassPos() {
		return $this->offset;
	}
}
?>
