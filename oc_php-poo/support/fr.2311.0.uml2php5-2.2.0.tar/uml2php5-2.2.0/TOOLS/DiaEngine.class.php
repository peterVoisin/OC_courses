<?php
/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Library General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * 
 *  Copyright 2005 KDO kdo@zpmag.com 
 */

require_once('DiaClassBuilder.class.php');

class DiaEngine extends DOMDocument {

	const COMPRESSION_LEVEL = 4;

	private $diafile = NULL ;
	private $diadoc = NULL;
	private $XP = NULL;
	private $nbObj = 0;

	/**
	 * @access public
	 */

	public final  function __construct($diafile) {
		$this->diafile = $diafile;
	}

	private function getNbID() {
		$NL = $this->XP->query('//dia:object');
		$this->nbObj = $NL->length ;
	}
	
	public function loadFile() {
		$zd = gzopen($this->diafile, 'r');
		$contents = gzread($zd, 256000);
		gzclose($zd);
		$this->loadXML($contents);
		$this->XP = new DOMXPath($this);
		$this->getNbID();
	}

	public final function buildFile() {
		$O = new DiaClassBuilder(array());
		$O->buildDiafile();	
		$this->loadXML($O->getXML());
		$this->XP = new DOMXPath($this);
	}
	
	public final function saveFile() {
		if (file_exists($this->diafile)) {
			$T = '-'.date('Ymd-Hi').'.dia';
			$N = str_replace('.dia',$T,$this->diafile);
			rename($this->diafile, $N);
		}
		$mode = 'wb'.self::COMPRESSION_LEVEL;
		if (($gz = gzopen($this->diafile, $mode))) {
			gzwrite($gz,  $this->saveXML());
			gzclose($gz);
		}
		else {
			$msg = 'Unable to write '.$this->diafile;
			$this->Error($msg);		
		}
	}

	public final function dumpXML() {
		echo $this->saveXML();
	}
	
	public final function dumpNode($node) {
		echo $this->saveXML($node);
	}
	
	
	public function diaGetNode($sxp, $ctx=NULL) {
		if ($ctx != NULL) {
   		return $this->XP->query($sxp, $ctx);
		}
		return $this->XP->query($sxp);
	}
	
	
	private final function Error($msg) {
		echo 'ERROR : '.$msg."\n";
		die ("ABORTED\n");
	}
	
	public function buildClassDiagram(&$T, $level) {
		$O = new DiaClassBuilder($T);
		$O->buildClass($this->nbObj, $level);
		$Doc2 = new DomDocument(1.0);
		$Doc2->loadXML($O->getXML()) ;
		$XP = new DOMXPath($Doc2);
		$L = $XP->query('//dia:diagram/*');
		$CNode = $L->item(0);
		$MNL = $this->XP->query('//dia:layer');
		$this->addChildNode($MNL->item(0), $CNode);
		$Obj = 'O'.$this->nbObj;
		$P = $O->getClassPos();
		$T['classinfos']['Obj'] = $Obj;
		$T['classinfos']['Xpos'] = $P['X'];
		$T['classinfos']['Ypos'] = $P['Y'];
		//var_dump($P); //die();
		$this->nbObj += 1;
		return TRUE;
	}
	
	public function addClassProperty(DOMNode $parent, $T) {
		$O = new DiaClassBuilder($T);
		$O->buildProperty();
		$Doc2 = new DomDocument(1.0);
		$Doc2->loadXML($O->getXML()) ;
		$XP = new DOMXPath($Doc2);
		$L = $XP->query('//dia:diagram/*');
		$CNode = $L->item(0);
		$this->addChildNode($parent, $CNode);
	}

	public function addClassMethod(DOMNode $parent, $T) {
		$O = new DiaClassBuilder($T);
		$O->buildMethod();
		$Doc2 = new DomDocument(1.0);
		$Doc2->loadXML($O->getXML()) ;
		$XP = new DOMXPath($Doc2);
		$L = $XP->query('//dia:diagram/*');
		$CNode = $L->item(0);
		$this->addChildNode($parent, $CNode);
	}

	public final function addGeneralization($L) {
		$O = new DiaClassBuilder(NULL);
		$O->diaGeneralization($L, $this->nbObj);
		$Doc2 = new DomDocument(1.0);
		$Doc2->loadXML($O->getXML()) ;
		$XP = new DOMXPath($Doc2);
		$L = $XP->query('//dia:diagram/*');
		$CNode = $L->item(0);
		$MNL = $this->XP->query('//dia:layer');
		$this->addChildNode($MNL->item(0), $CNode);
		$this->nbObj += 1;
		return TRUE;
		
	}
	
	private function addChildNode(DOMNode $parent, DOMNode $child) {
		$NewNode = $this->importnode($child, TRUE);
		$parent->appendchild($NewNode);
	}

}
?>
