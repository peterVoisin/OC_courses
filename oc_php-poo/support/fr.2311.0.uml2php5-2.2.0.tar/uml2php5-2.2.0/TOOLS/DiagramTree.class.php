<?php
/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Library General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * 
 *  Copyright 2005 KDO kdo@zpmag.com 
 */
 
 /**
  * Build a diagram tree of all the classes
  *
  * @version 0.1
  * @package   UMLTOOLS
  */
require_once('DiagramNode.class.php');

class DiagramTree {

	private $TREE = NULL;
	private $ON = NULL ;
	private $CN = NULL ;
	
	public function __construct() {
		$this->TREE = new DiagramNode('root', NULL);
	}
	
	public final function getTree() {
		return $this->TREE;
	}
	
	public final function addClass($C) {
		$N = $C['classinfos']['name'];
		$P = $C['classinfos']['parent'];
		$Node = new DiagramNode($N,$C);
		
		if ($P <> '') { // class has a parent
			if ($this->isOrphanNode($N)) {
				$Node->childs = $this->ON->childs;
				$this->deleteOrphanNode($N);
			}
			$this->addChild($P, $Node);
		}
		else { // class has no parent
			$this->addOrphan($Node, $N);
		}
	}
	
	private final function addOrphan(DiagramNode $node, $name) {
		if ($this->nodeExists($this->TREE, $name)) {
			$this->CN->C = $node->C;
		}
		else {
			$this->addChild('root', $node);
		}
	}

	private final function addChild($parent,DiagramNode $node) {
		$R = $this->TREE;
		if ($this->findParent($R, $parent)) {
			$this->CN->childs[] = $node;
		}
		else {
			// we create a 'temp' parent under root node
			$N = new DiagramNode($parent, NULL);
			$this->addChild('root', $N);
			$N->childs[] = $node;
		}
	}
	
	private final function findParent(DiagramNode $R, $P) {
		return $this->nodeExists($R, $P);
	}

	private final function nodeExists(DiagramNode $R, $P) {
		if ( $R->name == $P) {
			$this->CN = $R;
			return TRUE;
		}
		foreach ($R->childs as $T) {
			if ($this->nodeExists($T, $P)) {
				return TRUE;
			}
		}
		return FALSE;		
	}
	
	private final function isOrphanNode($N) {
		$R = $this->TREE;
		foreach ($R->childs as $T) {
			if ($T->name == $N) {
				$this->ON = $T;
				return TRUE;
			}
		}
		return FALSE;		
	}
	
	private final function deleteOrphanNode($N) {
		$R = $this->TREE;
		foreach ($R->childs as $T=>$V) {
			if ($V->name == $N) {
				unset($R->childs[$T]);
			}
		}
	}
	
	public final function dump($N=NULL) {
		static $i = '';
		
		if (!is_object($N)) {
			$N = $this->TREE;
		}
		echo $i.'+ '.$N->name."\n";
		$i .= '   ';
		foreach ($N->childs as $T) {
			$this->dump($T) ;
		}
		$i = substr($i, 3);
	}
}
