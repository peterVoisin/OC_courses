<?php
/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Library General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * 
 *  Copyright 2005 KDO kdo@zpmag.com 
 */
final class SoapClassParser {

	private $fc = ''		; // Code source lines

	private $CLASS			; // Parsed class array
	private $PCLASS		; // CLASS array pointer
	
	private $maxW = 0	; // Max width
	private $maxH = 1	; // Max height
	
	public function __construct($O, $cname) {
		$this->CLASS = array();
		$T = $O->__getFunctions();
		$this->PCLASS = & $this->CLASS;
		$this->getClassInfos($cname);
		$this->getMethodsInfos($T);
		$this->CLASS['classinfos']['H'] = $this->maxH;	
		$this->CLASS['classinfos']['W'] = $this->maxW;	
	}
	
	public final function getResult() {
		return ($this->PCLASS);
	}

	private final function updateMaxW($W) {
		if ($W > $this->maxW) {
			$this->maxW = $W;
		}
	}

	
	private function getClassInfos($cname) {
		$this->CLASS['classinfos'] = array();
		$T = & $this->CLASS['classinfos'];
		$T['name'] = $cname;
		$T['parent'] = '';
		$this->updateMaxW(strlen($T['name'])*2);
		$T['abstract'] = 'false';
		$T['stereotype'] = '#SOAP#';
	}
	
	private function getMethodsInfos($T) {
		$this->CLASS['methods'] = array();
		$METHODS = $T;
		$i = 0;
		foreach ($METHODS as $M) {
			$this->getMethodInfos($M, $i++);
		}
	}
	
	private function getMethodInfos( $M, $i) {
		$T = & $this->CLASS['methods'];
		$T[$i]['type'] = $this->getType__($M);
		$T[$i]['name'] = $this->getMethodName($M);
		$T[$i]['visibility'] = 0;
		$T[$i]['abstract'] = 'false';
		$T[$i]['final'] = FALSE;
		$T[$i]['static'] = 'false';
		$T[$i]['found'] = FALSE ;
		$this->getParametersInfos($M, $i);
		++$this->maxH;
	}

	private function getMethodName(&$M) {
		$i = strpos($M, '(');
		$T = substr($M, 0, $i);
		$M = substr($M, $i);
		return $T;
	}
	
	private function getParametersInfos($M, $i) {
		$this->CLASS['methods'][$i]['parameters'] = array();
		$M = str_replace('(','',$M);
		$M = str_replace(')','',$M);
		$M = str_replace(', ','§',$M);
		$PARAMS = explode('§', $M);
		$j = 0;
		$nameLen = strlen($this->CLASS['methods'][$i]['name']);
		foreach ($PARAMS as $P) {
			$this->paraLen = 0;
			$this->getParameterInfos($P, $i, $j++);
			$this->updateMaxW($nameLen + $this->paraLen +2);
		}
	}

	private function getParameterInfos(&$P, $i, $j) {
		$T = & $this->CLASS['methods'][$i]['parameters'];
		$T[$j]['type'] = $this->getType__($P);
		$N = str_replace('$','', $P);
		$T[$j]['name'] = $N;
		$T[$j]['value'] = '';
		$T[$j]['found'] = FALSE;
		$this->paraLen = strlen($T[$j]['type'].$T[$j]['name'].$T[$j]['value']);
	}

	private function getType__(&$M) {
		$i = strpos($M, ' ');
		$T = substr($M, 0, $i);
		$M = substr($M, $i+1);
		$T = ($T == 'void')?'':$T;		
		return $T;
	}
	
}
?>
