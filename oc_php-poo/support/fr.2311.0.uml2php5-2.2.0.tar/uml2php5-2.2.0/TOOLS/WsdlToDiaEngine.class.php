<?php
/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Library General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * 
 *  Copyright 2005 KDO kdo@zpmag.com 
 */
 
require_once('DiaEngine.class.php');
require_once('SoapClassParser.class.php');
require_once('DiagramTree.class.php');

final class WsdlToDiaEngine {

	const CLASS_EXT = '.class.php';

	private $curdir = '';
	private $diafile = '';
	
	private $WSDL_URL = '';
	private $DE = NULL;
	private $PC = 0;
	private $LC = array();
	private $CLASSNODE = NULL;
	private $CLASSROOT = NULL;
	private $CFiles = array();
	private $CDT = NULL;

	public final function __construct($url,$classname) {
		$this->cname =($classname != '')?$classname:'Webservice';
		$this->WSDL_URL = $url;
		$this->curdir = getcwd();
		$this->diafile = $this->curdir.'/'.$this->cname.'.dia';
		$this->CDT = new DiagramTree();
	}
	
	public final  function run() {
		$this->DE = new DiaEngine($this->diafile);
		$this->DE->buildFile();
		echo 'parsing class soapClient...';
		$SC = new soapClient($this->WSDL_URL);
		$CP = new SoapClassParser($SC, $this->cname) ;
		$this->PC = $CP->getResult();
		$this->CDT->addClass($this->PC);
		$this->buildDiagram();
		$this->DE->saveFile();
		echo 'OK!'."\n";
	}

	private final function Error($msg) {
		echo 'ERROR : '.$msg."\n";
		die ("ABORTED\n");
	}

	private final function buildDiagram($T=NULL) {
		static $level = 0;
		
		if (!is_object($T)) {
			$T = $this->CDT->getTree();
		}
		foreach ($T->childs as $N) {
			$this->buildNode($N, $level) ;
		}
		if (count($T->childs) > 0) {
			++$level;
		}
		foreach ($T->childs as $N) {
			$this->buildDiagram($N);
		}
	}

	private final function buildNode(DiagramNode $T, $L) {
		if ($T->name <> 'root') {
			$this->DE->buildClassDiagram($T->C, $L) ;
		}
	}

}
?>
